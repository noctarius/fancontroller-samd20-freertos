/*
 * task_uart.h
 */ 

#ifndef __TASK_UART_H__
#define __TASK_UART_H__

#include "atmel_start.h"
#include "FreeRTOS.h"

#ifdef __cplusplus
extern "C" {
	#endif

	#define TASK_UART_STACK_SIZE configMINIMAL_STACK_SIZE

	BaseType_t createUartTask();

	bool initUartTask();

	void killUartTask();

	#ifdef __cplusplus
}
#endif

#endif /* __TASK_UART_H__ */
