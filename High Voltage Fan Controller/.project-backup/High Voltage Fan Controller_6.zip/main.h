/*
 * main.h
 */ 

#ifndef __MAIN_H__
#define __MAIN_H__

#include <atmel_start.h>
#include <FreeRTOS.h>
#include <task.h>
#include "task_temperature.h"
#include "task_uart.h"

#ifdef __cplusplus
extern "C" {
#endif

// Common timeouts
#define ticks250ms	pdMS_TO_TICKS(250)
#define ticks100ms	pdMS_TO_TICKS(100)
#define ticks20ms	pdMS_TO_TICKS(20)

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H__ */