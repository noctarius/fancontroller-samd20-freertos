/*
 * task_uart.c
 */ 

#include "task_uart.h"

static xTaskHandle task_uart_pid = NULL;

// Internal async uart recv buffer
static uint8_t recv_buf[64];
static volatile uint8_t recv_buf_offset = 0;

// Internal uart io instance
static struct io_descriptor *io_usart0 = NULL;

// Internal message queue
static QueueHandle_t msg_queue = NULL;

static void tx_cb_USART_0(const struct usart_async_descriptor *const io_descr)
{
	/* Transfer completed */
}

static void rx_cb_USART_0(const struct usart_async_descriptor *const io_descr)
{
	/* Transfer completed */
}

static void err_cb_USART_0(const struct usart_async_descriptor *const io_descr)
{
	/* Transfer completed */
}

static void uart_write(const uint8_t *data, const uint8_t len)
{
	if (len > 0)
	{
		io_write(io_usart0, data, len);
		while (SERCOM1->USART.INTFLAG.bit.TXC == 0)
		{
			vTaskDelay(ticks20ms);
		}
	}
}

static int16_t uart_read(uint8_t *target, uint8_t len)
{
	// Non blocking
	uint8_t retval = usart_async_is_rx_not_empty(&USART_0);
	if (retval == 0)
	{
		return retval;
	}
	return io_read(io_usart0, target, len);
}

BaseType_t createUartTask()
{
	
}

bool initUartTask()
{
	
}

void killUartTask()
{
	
}
