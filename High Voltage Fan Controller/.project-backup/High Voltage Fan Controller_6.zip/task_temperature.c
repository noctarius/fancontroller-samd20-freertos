/*
 * task_temperature.c
 */ 

#include "task_temperature.h"

#define ticks10s	pdMS_TO_TICKS(10000)
#define ticks750ms	pdMS_TO_TICKS(750)
#define ticks250ms	pdMS_TO_TICKS(250)

static xTaskHandle task_temperature_pid = NULL;

static struct onewire_desc OW_1 = {
	pin: ONEWIRE
};

static struct ds18b20_desc *sensors[5];

static void temperature_task(void *pvParameters)
{
	(void) pvParameters;

	while (1) 
	{
		for (uint8_t i = 0; i < 5; i++)
		{
			struct ds18b20_desc *sensor = sensors[i];
			if (sensor == NULL) break;
			
			if (ds18b20_initiate_reading(sensor))
			{
				vTaskDelay(ticks750ms);
				ds18b20_get_reading(sensor);				
			}
		
			vTaskDelay(ticks250ms);
		}
		vTaskDelay(ticks10s);		
	}

	vTaskDelete(NULL);
}

BaseType_t createTemperatureTask()
{
	if (task_temperature_pid != NULL) return pdFAIL;
	return xTaskCreate(temperature_task, "DS18B20", TASK_TEMPERATURE_STACK_SIZE, NULL, 2, task_temperature_pid);
}

bool initTemperatureTask()
{
	onewire_search_t search;
	onewire_search_start(&OW_1, &search);
	
	uint8_t sensor_id = 0;
	onewire_addr_t addr;
	while (1)
	{
		if (sensor_id == 5)
			return true;

		addr = onewire_search_next(&search);
		if (addr == ONEWIRE_NONE)
		{
			if (sensor_id < 5)
				for (uint8_t i = sensor_id; i < 5; i++)
					sensors[i] = NULL;
			break;
		}
		
		struct ds18b20_desc sensor = {
			addr: addr,
			ow: &OW_1,
		};
		
		sensors[sensor_id] = &sensor;
		
		sensor_id++;
	}
	
	return true;
}

void killTemperatureTask()
{
	if (task_temperature_pid == NULL) return;
	vTaskDelete(task_temperature_pid);
	task_temperature_pid = NULL;
}
