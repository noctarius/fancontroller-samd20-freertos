/*
 * task_temperature.h
 */ 

#ifndef __TASK_TEMPERATURE_H__
#define __TASK_TEMPERATURE_H__

#include "atmel_start.h"
#include "FreeRTOS.h"
#include "ds18b20.h"

#ifdef __cplusplus
extern "C" {
#endif

#define TASK_TEMPERATURE_STACK_SIZE configMINIMAL_STACK_SIZE

BaseType_t createTemperatureTask();

bool initTemperatureTask();

void killTemperatureTask();

#ifdef __cplusplus
}
#endif

#endif /* __TASK_TEMPERATURE_H__ */
