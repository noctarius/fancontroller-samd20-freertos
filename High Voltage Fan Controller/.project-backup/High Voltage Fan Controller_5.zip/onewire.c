/*
 * onewire.c
 */ 

#include <string.h>
#include <FreeRTOS.h>
#include <task.h>
#include <atmel_start.h>
#include "onewire.h"

#define ONEWIRE_SELECT_ROM 0x55
#define ONEWIRE_SKIP_ROM   0xcc
#define ONEWIRE_SEARCH     0xf0

static inline bool _onewire_wait_for_bus(struct onewire_desc *dev, int max_wait)
{
	bool state;
	for (int i = 0; i < ((max_wait + 4) / 5); i++)
	{
		if (gpio_get_pin_level(dev->pin))
		break;
		delay_us(5);
	}
	state = gpio_set_pin_level(dev->pin);
	// Wait an extra 1us to make sure the devices have an adequate recovery
	// time before we drive things low again.
	delay_us(1);
	return state;
}

static void setup_pin(struct onewire_desc *dev, bool open_drain)
{
	gpio_set_direction(pin, open_drain ? OPEN_DRAIN_MODE : GPIO_MODE_OUTPUT);
	gpio_set_pull_mode(pin, GPIO_PULLUP_ONLY);
}


