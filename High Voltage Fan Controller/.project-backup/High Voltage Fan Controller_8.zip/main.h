/*
 * main.h
 */ 

#ifndef __MAIN_H__
#define __MAIN_H__

#include <atmel_start.h>
#include <FreeRTOS.h>
#include <task.h>
#include "task_temperature.h"
#include "task_uart.h"
#include "task_i2c.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H__ */