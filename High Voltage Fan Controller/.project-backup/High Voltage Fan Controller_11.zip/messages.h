
/*
 * messages.h
 */ 

#ifndef __MESSAGES_H__
#define __MESSAGES_H__

#define MSG_UART_START "UART started.\r\n"

#endif /* __MESSAGES_H__ */